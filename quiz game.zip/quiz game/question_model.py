
class Question:

    def __init__(self, q_text, a_answer):
        self.text = q_text
        self.answer = a_answer


# question_1 = Question("is my name toqi", "True")
# print(question_1.text)
# print(question_1.answer)












